sh build.sh
./gen_data 10 50 4 7 1.0 s r
