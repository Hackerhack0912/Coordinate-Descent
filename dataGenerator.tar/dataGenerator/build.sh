g++ gen_data.cpp -o gen_data
g++ gen_single.cpp -o gen_single.cpp
